@extends('layouts/base')
@section('content')

    @livewire('users')

@endsection