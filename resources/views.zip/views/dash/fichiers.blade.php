@extends('layouts/base')
@section('content')

    @livewire('fichiers')

@endsection