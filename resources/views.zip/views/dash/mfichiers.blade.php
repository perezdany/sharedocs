@extends('layouts/base')
@section('content')

    @livewire('mfichiers')

@endsection