@component('mail::message')
# A ne pas répondre!
	
Merci de ne pas répondre à ce mail.

Bonjour! Un nouveau fichier vient d'être partagé. <br>Vous devez acceder à votre espace pour voir le fichier

@component('mail::button', ['url' => $data['url'], 'color' => 'primary'])
Voir le fichier
@endcomponent
Cordialement,<br>
{{ config('app.name') }}
@endcomponent
